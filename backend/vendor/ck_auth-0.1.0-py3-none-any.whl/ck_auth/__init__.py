"""ck-auth — CK 平臺共享 auth/session 套件（Tier 1 import 式單一源）。

Phase 0 spike：僅證明「vendored-wheel import 式過 Docker」機制成立。
Phase 1 將併入 rotation / session / verify_refresh_token / refresh-SSO-fallback
（try_mint_session_from_sso_cookie）核心 + AsyncAuthAdapter / SyncAuthAdapter，
各 repo 由 copy vendoring 改為 import 本套件、釘版本，一次修全同步。

詳見 CK_Missive/docs/architecture/MODULARIZATION_CROSS_PROJECT_STRATEGY.md
"""

__version__ = "0.1.0"


def ping() -> str:
    """機制自證：consumer `import ck_auth; ck_auth.ping()` 回版本字串即證 import 式生效。"""
    return f"ck-auth {__version__} (import-式 Tier1 spike OK)"
